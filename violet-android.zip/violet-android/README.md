# Violet for Android

Two screens in one app:
- The app itself shows Violet with simulated sliders (for trying reactions).
- "Float Violet over other apps" puts a small Violet on top of everything. It reads real memory pressure,
  system thermal state, UI lag and CPU load where Android allows it. The notification shows the CPU source
  and has Pause monitoring and Stop buttons.

Gestures: drag to move. Double-tap plays voice clip 1. When CPU and lag are both high, a single tap plays clip 2.

Build without a computer: upload this zip (as is) to your GitHub repository, create
.github/workflows/android.yml with the text of android-build.yml, then Actions > Build Violet Android > Run workflow.
Download the artifact "violet-android-apk", unzip it, install app-debug.apk (allow installs from this source).
