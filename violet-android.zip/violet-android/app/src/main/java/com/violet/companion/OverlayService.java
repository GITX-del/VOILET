package com.violet.companion;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;

import java.io.BufferedReader;
import java.io.FileReader;

public class OverlayService extends Service {
    private static final String CHANNEL = "violet";
    private static final String ACTION_STOP = "com.violet.companion.STOP";
    private static final String ACTION_PAUSE = "com.violet.companion.PAUSE";

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private DragLayout box;
    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean paused = false;
    private long lastTick = 0;
    private long[] lastStat = null;
    private double runSmooth = 0;
    private String cpuSource = "estimating";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action) && box != null) {
            paused = !paused;
            runJs("window.violetPause&&window.violetPause(" + paused + ")");
            startForeground(1, buildNote());
            return START_NOT_STICKY;
        }
        if (box == null) {
            startForeground(1, buildNote());
            addOverlay();
            handler.postDelayed(tick, 1000);
        }
        return START_NOT_STICKY;
    }

    private void runJs(String js) {
        if (web != null) {
            web.evaluateJavascript(js, null);
        }
    }

    private Notification buildNote() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "Violet", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_dialog_info);
        b.setContentTitle("Violet is floating");
        b.setContentText(paused
                ? "Monitoring paused"
                : "Memory measured; CPU via " + cpuSource);
        b.setOngoing(true);
        b.addAction(0, paused ? "Resume monitoring" : "Pause monitoring", actionIntent(ACTION_PAUSE, 2));
        b.addAction(0, "Stop Violet", actionIntent(ACTION_STOP, 3));
        return b.build();
    }

    private PendingIntent actionIntent(String action, int code) {
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(action);
        return PendingIntent.getService(this, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void addOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        float d = getResources().getDisplayMetrics().density;
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(
                (int) (190 * d), (int) (170 * d), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (20 * d);
        lp.y = (int) (220 * d);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public boolean ok() {
                return true;
            }
        }, "VioletAndroid");
        web.loadUrl("file:///android_asset/index.html");

        box = new DragLayout(this);
        box.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        wm.addView(box, lp);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.uptimeMillis();
            long late = lastTick == 0 ? 0 : Math.max(0, now - lastTick - 1000);
            lastTick = now;
            if (!paused) {
                int cpu = readCpu();
                int mem = memPressure();
                int jank = (int) Math.min(100, late / 3);
                int lag = Math.max(Math.max(mem, jank), thermal());
                runJs("window.violetMetrics&&window.violetMetrics(" + cpu + "," + mem + "," + lag + ")");
            }
            handler.postDelayed(this, 1000);
        }
    };

    // Memory pressure: 0 when half of RAM is free or more, 100 when none is. Real value from Android.
    private int memPressure() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double free = mi.totalMem > 0 ? (double) mi.availMem / mi.totalMem : 0.5;
        int p = (int) Math.round(100 * (1 - free / 0.5));
        if (mi.lowMemory) {
            p = Math.max(p, 90);
        }
        return Math.max(0, Math.min(100, p));
    }

    // Thermal pressure from the system (Android 10+), 0 if unavailable.
    private int thermal() {
        if (Build.VERSION.SDK_INT < 29) {
            return 0;
        }
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        int[] map = {0, 30, 50, 75, 90, 100, 100};
        int t = pm.getCurrentThermalStatus();
        return t >= 0 && t < map.length ? map[t] : 0;
    }

    // CPU: Android often blocks apps from reading CPU load, so try three sources in order.
    private int readCpu() {
        try {
            BufferedReader r = new BufferedReader(new FileReader("/proc/stat"));
            String line = r.readLine();
            r.close();
            String[] p = line.trim().split("\\s+");
            long idle = Long.parseLong(p[4]) + Long.parseLong(p[5]);
            long total = 0;
            for (int i = 1; i < p.length && i < 9; i++) {
                total += Long.parseLong(p[i]);
            }
            int out = -1;
            if (lastStat != null && total > lastStat[0]) {
                out = (int) Math.round(100.0 * ((total - lastStat[0]) - (idle - lastStat[1])) / (total - lastStat[0]));
            }
            lastStat = new long[]{total, idle};
            if (out >= 0) {
                cpuSource = "device load";
                return Math.max(0, Math.min(100, out));
            }
            if (total > 0) {
                return 0;
            }
        } catch (Exception ignored) {
        }
        try {
            BufferedReader r = new BufferedReader(new FileReader("/proc/loadavg"));
            String[] p = r.readLine().trim().split(" ");
            r.close();
            double l1 = Double.parseDouble(p[0]);
            double running = Double.parseDouble(p[3].split("/")[0]) - 1;
            runSmooth = runSmooth * 0.7 + Math.max(0, running) * 0.3;
            int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
            cpuSource = "load average estimate";
            return (int) Math.max(0, Math.min(100, Math.round(100 * Math.max(l1, runSmooth) / cores)));
        } catch (Exception ignored) {
        }
        cpuSource = "thermal estimate";
        return Math.max(15, thermal());
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        if (box != null && wm != null) {
            wm.removeView(box);
            box = null;
        }
        if (web != null) {
            web.destroy();
            web = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    // Lets you drag the floating Violet; taps go to the page.
    private class DragLayout extends FrameLayout {
        private float downX, downY;
        private int startX, startY;
        private boolean dragging;
        private final int slop;

        DragLayout(Context c) {
            super(c);
            slop = ViewConfiguration.get(c).getScaledTouchSlop();
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                downX = e.getRawX();
                downY = e.getRawY();
                startX = lp.x;
                startY = lp.y;
                dragging = false;
            } else if (a == MotionEvent.ACTION_MOVE && !dragging
                    && Math.hypot(e.getRawX() - downX, e.getRawY() - downY) > slop * 2) {
                dragging = true;
            }
            return dragging;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!dragging) {
                return false;
            }
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_MOVE) {
                lp.x = (int) (startX + e.getRawX() - downX);
                lp.y = (int) (startY + e.getRawY() - downY);
                wm.updateViewLayout(this, lp);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                dragging = false;
            }
            return true;
        }
    }
}
