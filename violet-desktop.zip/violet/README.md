# Violet (desktop shell + browser preview)

Nothing here has been compiled yet. The first build is the real test.

## 1. Preview now, any PC, no install
Double-click `violet-preview.html`. Works offline. Readings are simulated by sliders.

## 2. Get installers without owning a PC (GitHub Actions)
1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder (keep the `.github` folder).
3. Open the repository's Actions tab, choose "Build Violet installers", click Run workflow.
4. After about 10-15 minutes, open the finished run and download the artifact for your system
   (Windows: .exe/.msi, macOS: .dmg on Apple Silicon, Linux: .AppImage/.deb).
If a job fails, send me the log text and I will fix it.
Unsigned apps trigger warnings: Windows SmartScreen ("More info" > "Run anyway"), macOS Gatekeeper (right-click > Open).

## 2b. Same thing, only from a phone
1. On github.com (desktop site mode helps) make a free account and a new repository.
2. Add file > Upload files: upload `violet-desktop.zip` itself, do not unzip it.
3. Add file > Create new file. In the name box type `.github/workflows/build.yml`, paste the contents of `phone-build.yml` (it is inside the zip), then commit.
4. Actions tab > "Build Violet installers" > Run workflow. Wait 10-15 minutes.
5. Open the finished run, scroll to Artifacts, download the one for the system of the PC you will use. Keep it (Drive, email) until you have a PC; then unzip and run the installer.

## 3. Build on a PC you can use
Install Node 20+ and Rust (rustup.rs). On Windows also install Visual Studio Build Tools (C++ workload).
On Linux install: libwebkit2gtk-4.1-dev build-essential libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev
Then in this folder: `npm install` then `npm run dev` (run) or `npm run build` (installer).

## Using Violet
Drag it with the mouse. The tray icon menu has: Show/hide, Pause monitoring, Always on top, Quit.
Violet makes no sound on its own. Double-click (or double-tap) Violet to play its voice clip; a mouth appears and lip-syncs only while it plays. Double-click again to stop.
When CPU and lag are both in their high state at once, a single tap instead plays a second voice clip, with bigger eyes and lip sync. Tap again to stop.
On Linux without a tray, use a desktop with an app-indicator extension, or Violet cannot be paused from the tray.
Metrics: CPU and memory are measured; the lag index is inferred from them.
Smile: Violet shows a small smile while the CPU, memory or lag reading stays above 70 (it goes away when all are below 65).
