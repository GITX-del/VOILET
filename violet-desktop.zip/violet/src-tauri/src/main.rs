#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::{thread, time::Duration};
use sysinfo::System;
use tauri::{
    menu::{CheckMenuItem, Menu, MenuItem},
    tray::TrayIconBuilder,
    Emitter, Manager,
};

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let paused = Arc::new(AtomicBool::new(false));

            // Tray menu: the owner can always show/hide, pause monitoring, or quit.
            let show = MenuItem::with_id(app, "show", "Show / hide Violet", true, None::<&str>)?;
            let pause = CheckMenuItem::with_id(app, "pause", "Pause monitoring", true, false, None::<&str>)?;
            let top = CheckMenuItem::with_id(app, "top", "Always on top", true, true, None::<&str>)?;
            let quit = MenuItem::with_id(app, "quit", "Quit Violet", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&show, &pause, &top, &quit])?;

            let (pause_c, top_c, paused_c) = (pause.clone(), top.clone(), paused.clone());
            TrayIconBuilder::new()
                .icon(app.default_window_icon().unwrap().clone())
                .tooltip("Violet")
                .menu(&menu)
                .on_menu_event(move |app, event| match event.id.as_ref() {
                    "quit" => app.exit(0),
                    "show" => {
                        if let Some(w) = app.get_webview_window("main") {
                            if w.is_visible().unwrap_or(true) {
                                let _ = w.hide();
                            } else {
                                let _ = w.show();
                            }
                        }
                    }
                    "pause" => {
                        let on = pause_c.is_checked().unwrap_or(false);
                        paused_c.store(on, Ordering::Relaxed);
                        let _ = app.emit("monitoring", !on);
                    }
                    "top" => {
                        if let Some(w) = app.get_webview_window("main") {
                            let _ = w.set_always_on_top(top_c.is_checked().unwrap_or(true));
                        }
                    }
                    _ => {}
                })
                .build(app)?;

            // Metrics: CPU and memory once per second, only while monitoring is on.
            let handle = app.handle().clone();
            thread::spawn(move || {
                let mut sys = System::new();
                sys.refresh_cpu_usage(); // baseline; the first reading is not meaningful
                loop {
                    thread::sleep(Duration::from_secs(1));
                    if paused.load(Ordering::Relaxed) {
                        continue;
                    }
                    sys.refresh_cpu_usage();
                    sys.refresh_memory();
                    let total = sys.total_memory();
                    let mem = if total > 0 {
                        sys.used_memory() as f64 / total as f64 * 100.0
                    } else {
                        0.0
                    };
                    let _ = handle.emit(
                        "metrics",
                        serde_json::json!({ "cpu": sys.global_cpu_usage(), "mem": mem }),
                    );
                }
            });
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running Violet");
}
